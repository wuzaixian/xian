# Web后台管理系统

## 🎉 功能已完成！

---

## 🚀 快速启动

### 方式1: 使用启动脚本（推荐）

```bash
cd /workspace/projects
./scripts/start_web_backend.sh
```

### 方式2: 直接启动

```bash
cd /workspace/projects
streamlit run web_backend.py
```

### 方式3: 后台运行

```bash
cd /workspace/projects
streamlit run web_backend.py --server.port 8501 --server.headless true &
```

---

## 🌐 访问地址

启动后，在浏览器中访问：

- **本地**: http://localhost:8501
- **网络**: http://169.254.101.215:8501

---

## 🔐 登录信息

- **用户名**: `admin`
- **密码**: `admin123456`

---

## 📋 功能模块

### 1. 📊 仪表盘
- 系统概览数据
- 学生分布统计
- 最近学习活动

### 2. 👥 学生管理
- 学生列表查看
- 按年级筛选
- 学生详情和学习进度

### 3. 📚 考试大纲管理
- 查看所有大纲
- 添加新大纲
- 编辑和删除大纲

### 4. 📝 操作日志
- 查看所有管理操作
- 操作审计追踪

---

## 🎨 界面特点

- ✅ 现代化设计
- ✅ 响应式布局
- ✅ 直观的操作界面
- ✅ 实时数据更新
- ✅ 完善的权限控制

---

## 📖 详细文档

查看完整使用指南：
- `docs/Web后台使用指南.md`

---

## 💡 技术栈

- **Streamlit**: Web应用框架
- **PostgreSQL**: 数据库
- **SQLAlchemy**: ORM
- **Pandas**: 数据处理

---

## 📞 问题反馈

如遇问题，请查看操作日志或重新启动服务。
