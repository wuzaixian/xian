from utils.runnable.wrapper import to_runnable

__all__ = ["to_runnable"]
