"""
后台管理 Manager
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from datetime import datetime
import hashlib

from storage.database.shared.model import Admin, AdminLog, ExamSyllabus, Student, Progress, WrongAnswer, Question


# Pydantic Models
class AdminCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50, description="用户名")
    password: str = Field(..., min_length=6, description="密码")
    email: Optional[str] = Field(None, description="邮箱")
    role: str = Field("admin", description="角色")


class AdminUpdate(BaseModel):
    email: Optional[str] = None
    is_active: Optional[bool] = None


class ExamSyllabusCreate(BaseModel):
    grade: str = Field(..., description="年级")
    subject: str = Field(..., description="科目")
    title: str = Field(..., description="大纲标题")
    content: str = Field(..., description="大纲内容")
    version: str = Field("1.0", description="版本号")


class ExamSyllabusUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    version: Optional[str] = None
    is_active: Optional[bool] = None


class AdminManager:
    """管理员管理类"""
    
    def _hash_password(self, password: str) -> str:
        """密码哈希"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def create_admin(self, db: Session, admin_in: AdminCreate) -> Admin:
        """创建管理员"""
        # 检查用户名是否存在
        existing = db.query(Admin).filter(Admin.username == admin_in.username).first()
        if existing:
            raise ValueError(f"用户名 '{admin_in.username}' 已存在")
        
        admin_data = admin_in.model_dump(exclude={"password"})
        admin_data["password_hash"] = self._hash_password(admin_in.password)
        admin_data["is_active"] = True
        
        db_admin = Admin(**admin_data)
        db.add(db_admin)
        try:
            db.commit()
            db.refresh(db_admin)
            return db_admin
        except Exception as e:
            db.rollback()
            raise
    
    def verify_admin(self, db: Session, username: str, password: str) -> Optional[Admin]:
        """验证管理员账号"""
        password_hash = self._hash_password(password)
        admin = db.query(Admin).filter(
            Admin.username == username,
            Admin.password_hash == password_hash,
            Admin.is_active == True
        ).first()
        
        if admin:
            # 更新最后登录时间
            admin.last_login = datetime.now()
            db.add(admin)
            try:
                db.commit()
            except Exception:
                db.rollback()
        
        return admin
    
    def get_admins(self, db: Session, skip: int = 0, limit: int = 100) -> List[Admin]:
        """获取管理员列表"""
        return db.query(Admin).offset(skip).limit(limit).all()


class AdminLogManager:
    """操作日志管理类"""
    
    def log_action(
        self,
        db: Session,
        admin_id: int,
        action: str,
        resource_type: Optional[str] = None,
        resource_id: Optional[int] = None,
        details: Optional[str] = None,
        ip_address: Optional[str] = None
    ) -> AdminLog:
        """记录操作日志"""
        log = AdminLog(
            admin_id=admin_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details,
            ip_address=ip_address
        )
        db.add(log)
        try:
            db.commit()
            db.refresh(log)
            return log
        except Exception:
            db.rollback()
            raise
    
    def get_logs(
        self,
        db: Session,
        admin_id: Optional[int] = None,
        action: Optional[str] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[AdminLog]:
        """获取操作日志"""
        query = db.query(AdminLog)
        
        if admin_id:
            query = query.filter(AdminLog.admin_id == admin_id)
        if action:
            query = query.filter(AdminLog.action == action)
        
        return query.order_by(AdminLog.created_at.desc()).offset(skip).limit(limit).all()


class ExamSyllabusManager:
    """考试大纲管理类"""
    
    def create_syllabus(self, db: Session, syllabus_in: ExamSyllabusCreate, admin_id: int) -> ExamSyllabus:
        """创建考试大纲"""
        # 检查是否已存在
        existing = db.query(ExamSyllabus).filter(
            ExamSyllabus.grade == syllabus_in.grade,
            ExamSyllabus.subject == syllabus_in.subject,
            ExamSyllabus.is_active == True
        ).first()
        
        if existing:
            raise ValueError(f"{syllabus_in.grade}{syllabus_in.subject} 的考试大纲已存在")
        
        syllabus_data = syllabus_in.model_dump()
        syllabus_data["created_by"] = admin_id
        
        db_syllabus = ExamSyllabus(**syllabus_data)
        db.add(db_syllabus)
        try:
            db.commit()
            db.refresh(db_syllabus)
            return db_syllabus
        except Exception as e:
            db.rollback()
            raise
    
    def update_syllabus(
        self,
        db: Session,
        syllabus_id: int,
        syllabus_in: ExamSyllabusUpdate
    ) -> Optional[ExamSyllabus]:
        """更新考试大纲"""
        db_syllabus = db.query(ExamSyllabus).filter(ExamSyllabus.id == syllabus_id).first()
        if not db_syllabus:
            return None
        
        update_data = syllabus_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            if hasattr(db_syllabus, field):
                setattr(db_syllabus, field, value)
        
        db.add(db_syllabus)
        try:
            db.commit()
            db.refresh(db_syllabus)
            return db_syllabus
        except Exception:
            db.rollback()
            raise
    
    def get_syllabi(
        self,
        db: Session,
        grade: Optional[str] = None,
        subject: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> List[ExamSyllabus]:
        """获取考试大纲列表"""
        query = db.query(ExamSyllabus)
        
        if grade:
            query = query.filter(ExamSyllabus.grade == grade)
        if subject:
            query = query.filter(ExamSyllabus.subject == subject)
        if is_active is not None:
            query = query.filter(ExamSyllabus.is_active == is_active)
        
        return query.order_by(ExamSyllabus.grade, ExamSyllabus.subject).all()
    
    def delete_syllabus(self, db: Session, syllabus_id: int) -> bool:
        """删除考试大纲（软删除）"""
        db_syllabus = db.query(ExamSyllabus).filter(ExamSyllabus.id == syllabus_id).first()
        if not db_syllabus:
            return False
        
        db_syllabus.is_active = False
        db.add(db_syllabus)
        try:
            db.commit()
            return True
        except Exception:
            db.rollback()
            return False


class DashboardManager:
    """仪表盘数据管理类"""
    
    def get_overview(self, db: Session) -> Dict[str, Any]:
        """获取系统概览数据"""
        # 学生统计
        total_students = db.query(Student).count()
        
        # 知识点统计
        total_knowledge_points = db.query(Progress.knowledge_point_id).distinct().count()
        
        # 题目统计
        total_questions = db.query(Question).count()
        
        # 今日学习统计
        today = datetime.now().date()
        today_study_count = db.query(Progress).filter(
            Progress.last_study_date >= today
        ).count()
        
        # 错题统计
        total_wrong_answers = db.query(WrongAnswer).count()
        
        return {
            "学生总数": total_students,
            "知识点总数": total_knowledge_points,
            "题目总数": total_questions,
            "今日学习人数": today_study_count,
            "错题总数": total_wrong_answers
        }
    
    def get_student_stats(self, db: Session) -> List[Dict[str, Any]]:
        """获取学生统计数据（按年级分组）"""
        from sqlalchemy import func
        
        stats = db.query(
            Student.grade,
            func.count(Student.id).label('count'),
            func.sum(Student.total_study_hours).label('total_hours')
        ).group_by(Student.grade).all()
        
        return [
            {
                "年级": stat.grade,
                "学生人数": stat.count,
                "总学习时长": f"{stat.total_hours or 0:.1f}小时"
            }
            for stat in stats
        ]
    
    def get_recent_activities(self, db: Session, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近活动"""
        activities = []
        
        # 最近的学习记录
        recent_progress = db.query(Progress, Student).join(
            Student, Progress.student_id == Student.id
        ).order_by(Progress.last_study_date.desc()).limit(limit).all()
        
        for progress, student in recent_progress:
            activities.append({
                "时间": progress.last_study_date.strftime("%Y-%m-%d %H:%M") if progress.last_study_date else "",
                "学生": student.name,
                "年级": student.grade,
                "活动": "学习知识点",
                "详情": f"学习次数: {progress.study_count}"
            })
        
        return activities
