from coze_coding_dev_sdk.database import Base
from sqlalchemy import MetaData
from sqlalchemy import BigInteger, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text, JSON, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from typing import Optional
from datetime import datetime

metadata = MetaData()

class Student(Base):
    """学生信息表"""
    __tablename__ = "students"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="学生ID")
    grade: Mapped[str] = mapped_column(String(50), nullable=False, comment="年级: 初中7年级/初中8年级/初中9年级/高一/高二/高三")
    subjects: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="学习的科目,逗号分隔")
    name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, comment="学生姓名")
    total_study_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False, comment="总学习时长(小时)")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now(), nullable=True)

    # 关系
    progress_records: Mapped[list["Progress"]] = relationship("Progress", back_populates="student", cascade="all, delete-orphan")
    wrong_answers: Mapped[list["WrongAnswer"]] = relationship("WrongAnswer", back_populates="student", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_students_grade", "grade"),
    )

class KnowledgePoint(Base):
    """知识点表"""
    __tablename__ = "knowledge_points"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="知识点ID")
    grade: Mapped[str] = mapped_column(String(50), nullable=False, comment="年级")
    subject: Mapped[str] = mapped_column(String(50), nullable=False, comment="科目")
    topic: Mapped[str] = mapped_column(String(200), nullable=False, comment="知识点主题")
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="知识点内容")
    difficulty: Mapped[str] = mapped_column(String(20), nullable=False, default="中等", comment="难度: 基础/中等/困难")
    related_points: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="关联知识点ID,逗号分隔")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    questions: Mapped[list["Question"]] = relationship("Question", back_populates="knowledge_point", cascade="all, delete-orphan")
    progress_records: Mapped[list["Progress"]] = relationship("Progress", back_populates="knowledge_point", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_knowledge_points_grade_subject", "grade", "subject"),
    )

class Question(Base):
    """题目表"""
    __tablename__ = "questions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="题目ID")
    knowledge_point_id: Mapped[int] = mapped_column(Integer, ForeignKey("knowledge_points.id"), nullable=False, comment="知识点ID")
    content: Mapped[str] = mapped_column(Text, nullable=False, comment="题目内容")
    question_type: Mapped[str] = mapped_column(String(50), nullable=False, default="选择题", comment="题目类型: 选择题/填空题/简答题/计算题")
    difficulty: Mapped[str] = mapped_column(String(20), nullable=False, default="中等", comment="难度: 基础/中等/困难")
    answer: Mapped[str] = mapped_column(Text, nullable=False, comment="正确答案")
    explanation: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="题目解析")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    knowledge_point: Mapped["KnowledgePoint"] = relationship("KnowledgePoint", back_populates="questions")
    wrong_answers: Mapped[list["WrongAnswer"]] = relationship("WrongAnswer", back_populates="question", cascade="all, delete-orphan")

class WrongAnswer(Base):
    """错题记录表"""
    __tablename__ = "wrong_answers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="错题ID")
    student_id: Mapped[int] = mapped_column(Integer, ForeignKey("students.id"), nullable=False, comment="学生ID")
    question_id: Mapped[int] = mapped_column(Integer, ForeignKey("questions.id"), nullable=False, comment="题目ID")
    wrong_answer: Mapped[str] = mapped_column(Text, nullable=False, comment="错误答案")
    wrong_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="错因分析")
    review_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="复习次数")
    last_review_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, comment="最后复习日期")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    student: Mapped["Student"] = relationship("Student", back_populates="wrong_answers")
    question: Mapped["Question"] = relationship("Question", back_populates="wrong_answers")

class Progress(Base):
    """学习进度表"""
    __tablename__ = "progress"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="进度ID")
    student_id: Mapped[int] = mapped_column(Integer, ForeignKey("students.id"), nullable=False, comment="学生ID")
    knowledge_point_id: Mapped[int] = mapped_column(Integer, ForeignKey("knowledge_points.id"), nullable=False, comment="知识点ID")
    mastery_level: Mapped[float] = mapped_column(Float, default=0.0, nullable=False, comment="掌握度 0.0-1.0")
    study_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="学习次数")
    last_study_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, comment="最后学习日期")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    student: Mapped["Student"] = relationship("Student", back_populates="progress_records")
    knowledge_point: Mapped["KnowledgePoint"] = relationship("KnowledgePoint", back_populates="progress_records")

    __table_args__ = (
        Index("ix_progress_student_knowledge", "student_id", "knowledge_point_id"),
    )

class Admin(Base):
    """管理员表"""
    __tablename__ = "admins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="管理员ID")
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, comment="用户名")
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False, comment="密码哈希")
    email: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, comment="邮箱")
    role: Mapped[str] = mapped_column(String(20), nullable=False, default="admin", comment="角色: admin/super_admin")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, comment="是否激活")
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, comment="最后登录时间")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    logs: Mapped[list["AdminLog"]] = relationship("AdminLog", back_populates="admin", cascade="all, delete-orphan")

class AdminLog(Base):
    """管理员操作日志表"""
    __tablename__ = "admin_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="日志ID")
    admin_id: Mapped[int] = mapped_column(Integer, ForeignKey("admins.id"), nullable=False, comment="管理员ID")
    action: Mapped[str] = mapped_column(String(100), nullable=False, comment="操作类型")
    resource_type: Mapped[str] = mapped_column(String(50), nullable=True, comment="资源类型")
    resource_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, comment="资源ID")
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="操作详情")
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True, comment="IP地址")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # 关系
    admin: Mapped["Admin"] = relationship("Admin", back_populates="logs")

class ExamSyllabus(Base):
    """考试大纲表"""
    __tablename__ = "exam_syllabus"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, comment="大纲ID")
    grade: Mapped[str] = mapped_column(String(50), nullable=False, comment="年级")
    subject: Mapped[str] = mapped_column(String(50), nullable=False, comment="科目")
    title: Mapped[str] = mapped_column(String(200), nullable=False, comment="大纲标题")
    content: Mapped[str] = mapped_column(Text, nullable=False, comment="大纲内容(Markdown)")
    version: Mapped[str] = mapped_column(String(20), default="1.0", nullable=False, comment="版本号")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, comment="是否启用")
    created_by: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("admins.id"), nullable=True, comment="创建者ID")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), onupdate=func.now(), nullable=True)

    # 关系
    creator: Mapped[Optional["Admin"]] = relationship("Admin")

    __table_args__ = (
        Index("ix_exam_syllabus_grade_subject", "grade", "subject"),
    )

