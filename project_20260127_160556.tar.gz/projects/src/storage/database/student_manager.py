"""
学生数据管理 Manager
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from datetime import datetime

from storage.database.shared.model import Student, Progress, WrongAnswer, Question, KnowledgePoint


# Pydantic Models
class StudentCreate(BaseModel):
    name: str = Field(..., description="学生姓名")
    grade: str = Field(..., description="年级")
    subjects: Optional[str] = Field(None, description="学习的科目")


class StudentUpdate(BaseModel):
    name: Optional[str] = None
    subjects: Optional[str] = None
    total_study_hours: Optional[float] = None


class ProgressCreate(BaseModel):
    student_id: int = Field(..., description="学生ID")
    knowledge_point_id: int = Field(..., description="知识点ID")
    mastery_level: float = Field(0.0, description="掌握度 0.0-1.0")
    study_count: int = Field(1, description="学习次数")


class ProgressUpdate(BaseModel):
    mastery_level: Optional[float] = None
    study_count: Optional[int] = None
    last_study_date: Optional[datetime] = None


class WrongAnswerCreate(BaseModel):
    student_id: int = Field(..., description="学生ID")
    question_id: int = Field(..., description="题目ID")
    wrong_answer: str = Field(..., description="错误答案")
    wrong_reason: Optional[str] = Field(None, description="错因分析")


class StudentManager:
    """学生数据管理类"""
    
    def create_student(self, db: Session, student_in: StudentCreate) -> Student:
        """创建学生"""
        student_data = student_in.model_dump()
        db_student = Student(**student_data)
        db.add(db_student)
        try:
            db.commit()
            db.refresh(db_student)
            return db_student
        except Exception as e:
            db.rollback()
            raise
    
    def get_or_create_student(self, db: Session, name: str, grade: str, subjects: Optional[str] = None) -> Student:
        """获取或创建学生"""
        student = db.query(Student).filter(Student.name == name, Student.grade == grade).first()
        if not student:
            student_in = StudentCreate(name=name, grade=grade, subjects=subjects)
            student = self.create_student(db, student_in)
        return student
    
    def update_student(self, db: Session, student_id: int, student_in: StudentUpdate) -> Optional[Student]:
        """更新学生信息"""
        db_student = db.query(Student).filter(Student.id == student_id).first()
        if not db_student:
            return None
        update_data = student_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            if hasattr(db_student, field):
                setattr(db_student, field, value)
        db.add(db_student)
        try:
            db.commit()
            db.refresh(db_student)
            return db_student
        except Exception:
            db.rollback()
            raise


class ProgressManager:
    """学习进度管理类"""
    
    def save_progress(self, db: Session, progress_in: ProgressCreate) -> Progress:
        """保存或更新学习进度"""
        # 查找是否已有记录
        existing = db.query(Progress).filter(
            Progress.student_id == progress_in.student_id,
            Progress.knowledge_point_id == progress_in.knowledge_point_id
        ).first()
        
        if existing:
            # 更新已有记录
            if progress_in.mastery_level is not None:
                existing.mastery_level = progress_in.mastery_level
            existing.study_count += progress_in.study_count
            existing.last_study_date = datetime.now()
            db.add(existing)
        else:
            # 创建新记录
            progress_data = progress_in.model_dump()
            progress_data['last_study_date'] = datetime.now()
            existing = Progress(**progress_data)
            db.add(existing)
        
        try:
            db.commit()
            db.refresh(existing)
            return existing
        except Exception as e:
            db.rollback()
            raise
    
    def get_student_progress(self, db: Session, student_id: int, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """获取学生的学习进度"""
        query = db.query(Progress, KnowledgePoint).join(
            KnowledgePoint, Progress.knowledge_point_id == KnowledgePoint.id
        ).filter(Progress.student_id == student_id)
        
        if subject:
            query = query.filter(KnowledgePoint.subject == subject)
        
        results = query.all()
        
        progress_list = []
        for progress, kp in results:
            progress_list.append({
                "知识点": kp.topic,
                "科目": kp.subject,
                "难度": kp.difficulty,
                "掌握度": f"{progress.mastery_level * 100:.1f}%",
                "学习次数": progress.study_count,
                "最后学习": progress.last_study_date.strftime("%Y-%m-%d") if progress.last_study_date else "未学习"
            })
        
        return progress_list
    
    def get_progress_summary(self, db: Session, student_id: int) -> Dict[str, Any]:
        """获取学习进度摘要"""
        progresses = db.query(Progress).filter(Progress.student_id == student_id).all()
        
        if not progresses:
            return {"总知识点": 0, "平均掌握度": 0, "已学习": 0, "未学习": 0}
        
        total = len(progresses)
        studied = sum(1 for p in progresses if p.study_count > 0)
        avg_mastery = sum(p.mastery_level for p in progresses) / total
        
        return {
            "总知识点": total,
            "已学习": studied,
            "未学习": total - studied,
            "平均掌握度": f"{avg_mastery * 100:.1f}%"
        }


class WrongAnswerManager:
    """错题管理类"""
    
    def record_wrong_answer(self, db: Session, wrong_in: WrongAnswerCreate) -> WrongAnswer:
        """记录错题"""
        wrong_data = wrong_in.model_dump()
        db_wrong = WrongAnswer(**wrong_data)
        db.add(db_wrong)
        try:
            db.commit()
            db.refresh(db_wrong)
            return db_wrong
        except Exception as e:
            db.rollback()
            raise
    
    def get_wrong_answers(self, db: Session, student_id: int, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """获取学生的错题"""
        query = db.query(WrongAnswer, Question, KnowledgePoint).join(
            Question, WrongAnswer.question_id == Question.id
        ).join(
            KnowledgePoint, Question.knowledge_point_id == KnowledgePoint.id
        ).filter(WrongAnswer.student_id == student_id)
        
        if subject:
            query = query.filter(KnowledgePoint.subject == subject)
        
        results = query.all()
        
        wrong_list = []
        for wa, q, kp in results:
            wrong_list.append({
                "题目ID": q.id,
                "科目": kp.subject,
                "知识点": kp.topic,
                "题目内容": q.content[:100] + "..." if len(q.content) > 100 else q.content,
                "错误答案": wa.wrong_answer,
                "错因": wa.wrong_reason or "未分析",
                "复习次数": wa.review_count,
                "最后复习": wa.last_review_date.strftime("%Y-%m-%d") if wa.last_review_date else "未复习"
            })
        
        return wrong_list
