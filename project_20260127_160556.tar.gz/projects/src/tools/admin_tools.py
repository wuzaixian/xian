"""
后台管理工具
"""
from typing import Optional, List, Dict, Any
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk.database import get_session
from storage.database.admin_manager import (
    DashboardManager,
    AdminLogManager,
    ExamSyllabusManager,
    ExamSyllabusCreate,
    ExamSyllabusUpdate
)


@tool
def get_dashboard_overview(runtime: ToolRuntime) -> str:
    """
    获取系统概览数据（仪表盘）
    
    Returns:
        系统概览数据，包括学生总数、知识点总数、题目总数、今日学习人数、错题总数
    """
    try:
        db = get_session()
        try:
            dashboard_mgr = DashboardManager()
            
            # 获取概览数据
            overview = dashboard_mgr.get_overview(db)
            
            # 获取学生统计
            student_stats = dashboard_mgr.get_student_stats(db)
            
            # 构建报告
            report = """📊 系统概览
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📈 核心指标:
"""
            for key, value in overview.items():
                report += f"• {key}: {value}\n"
            
            report += "\n👥 学生分布（按年级）:\n"
            for stat in student_stats:
                report += f"• {stat['年级']}: {stat['学生人数']}人, 总学习时长 {stat['总学习时长']}\n"
            
            return report
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取系统概览失败: {str(e)}"


@tool
def get_student_list(
    runtime: ToolRuntime,
    grade: Optional[str] = None,
    limit: int = 20
) -> str:
    """
    获取学生列表
    
    Args:
        runtime: 工具运行时上下文
        grade: 年级筛选（可选）
        limit: 返回数量限制
    
    Returns:
        学生列表
    """
    try:
        db = get_session()
        try:
            from storage.database.shared.model import Student
            from sqlalchemy import desc
            
            query = db.query(Student)
            
            if grade:
                query = query.filter(Student.grade == grade)
            
            students = query.order_by(desc(Student.created_at)).limit(limit).all()
            
            if not students:
                return "暂无学生数据"
            
            result = f"👥 学生列表（共{len(students)}人）\n"
            result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            result += f"{'ID':<5} {'姓名':<15} {'年级':<15} {'科目':<30} {'学习时长':<10}\n"
            result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            
            for s in students:
                result += f"{s.id:<5} {s.name or '未设置':<15} {s.grade:<15} {s.subjects or '未设置':<30} {s.total_study_hours:<10.1f}\n"
            
            return result
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取学生列表失败: {str(e)}"


@tool
def add_exam_syllabus(
    runtime: ToolRuntime,
    grade: str,
    subject: str,
    title: str,
    content: str
) -> str:
    """
    添加考试大纲
    
    Args:
        runtime: 工具运行时上下文
        grade: 年级（如：初中9年级、高一）
        subject: 科目（如：数学、语文、英语）
        title: 大纲标题
        content: 大纲内容（Markdown格式）
    
    Returns:
        添加结果
    """
    try:
        db = get_session()
        try:
            syllabus_mgr = ExamSyllabusManager()
            
            syllabus_in = ExamSyllabusCreate(
                grade=grade,
                subject=subject,
                title=title,
                content=content,
                version="1.0"
            )
            
            syllabus = syllabus_mgr.create_syllabus(db, syllabus_in, admin_id=1)
            
            # 记录操作日志
            log_mgr = AdminLogManager()
            log_mgr.log_action(
                db,
                admin_id=1,
                action="create_syllabus",
                resource_type="exam_syllabus",
                resource_id=syllabus.id,
                details=f"创建考试大纲: {grade}{subject} - {title}"
            )
            
            return f"""✅ 考试大纲添加成功!

📋 大纲信息:
• ID: {syllabus.id}
• 年级: {syllabus.grade}
• 科目: {syllabus.subject}
• 标题: {syllabus.title}
• 版本: {syllabus.version}
• 创建时间: {syllabus.created_at.strftime('%Y-%m-%d %H:%M')}

💡 提示: 大纲内容已保存到数据库，可通过智能体检索使用。"""
            
        finally:
            db.close()
            
    except ValueError as e:
        return f"⚠️ {str(e)}"
    except Exception as e:
        return f"❌ 添加考试大纲失败: {str(e)}"


@tool
def list_exam_syllabi(
    runtime: ToolRuntime,
    grade: Optional[str] = None,
    subject: Optional[str] = None
) -> str:
    """
    列出考试大纲
    
    Args:
        runtime: 工具运行时上下文
        grade: 年级筛选（可选）
        subject: 科目筛选（可选）
    
    Returns:
        考试大纲列表
    """
    try:
        db = get_session()
        try:
            syllabus_mgr = ExamSyllabusManager()
            syllabi = syllabus_mgr.get_syllabi(db, grade=grade, subject=subject, is_active=True)
            
            if not syllabi:
                return "暂无考试大纲数据"
            
            result = f"📚 考试大纲列表（共{len(syllabi)}个）\n"
            result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            
            for s in syllabi:
                result += f"""
• {s.grade} - {s.subject}
  标题: {s.title}
  版本: {s.version}
  创建时间: {s.created_at.strftime('%Y-%m-%d')}
  状态: {'✅ 启用' if s.is_active else '❌ 禁用'}
"""
            
            return result
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取考试大纲列表失败: {str(e)}"


@tool
def get_system_stats(runtime: ToolRuntime) -> str:
    """
    获取系统统计数据
    
    Returns:
        系统详细统计数据
    """
    try:
        db = get_session()
        try:
            dashboard_mgr = DashboardManager()
            
            # 获取各类统计
            overview = dashboard_mgr.get_overview(db)
            student_stats = dashboard_mgr.get_student_stats(db)
            recent_activities = dashboard_mgr.get_recent_activities(db, limit=5)
            
            report = f"""📊 系统详细统计报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📈 核心指标:
"""
            for key, value in overview.items():
                report += f"  • {key}: {value}\n"
            
            report += "\n👥 学生分布:\n"
            for stat in student_stats:
                report += f"  • {stat['年级']}: {stat['学生人数']}人 (总学习时长: {stat['总学习时长']})\n"
            
            report += "\n🕐 最近活动:\n"
            for activity in recent_activities:
                report += f"  • [{activity['时间']}] {activity['学生']} ({activity['年级']}) - {activity['活动']}\n"
            
            return report
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取统计数据失败: {str(e)}"


@tool
def get_admin_logs(runtime: ToolRuntime, limit: int = 20) -> str:
    """
    获取管理员操作日志
    
    Args:
        runtime: 工具运行时上下文
        limit: 返回数量限制
    
    Returns:
        操作日志列表
    """
    try:
        db = get_session()
        try:
            from storage.database.shared.model import AdminLog, Admin
            
            logs = db.query(AdminLog, Admin).join(
                Admin, AdminLog.admin_id == Admin.id
            ).order_by(AdminLog.created_at.desc()).limit(limit).all()
            
            if not logs:
                return "暂无操作日志"
            
            result = f"📝 管理员操作日志（最近{len(logs)}条）\n"
            result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            
            for log, admin in logs:
                result += f"""
• [{log.created_at.strftime('%Y-%m-%d %H:%M:%S')}]
  管理员: {admin.username}
  操作: {log.action}
  资源: {log.resource_type or 'N/A'} (ID: {log.resource_id or 'N/A'})
  详情: {log.details or '无'}
  IP: {log.ip_address or 'N/A'}
"""
            
            return result
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取操作日志失败: {str(e)}"
