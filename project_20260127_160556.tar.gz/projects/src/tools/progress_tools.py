"""
学习进度管理工具
"""
from typing import Optional
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk.database import get_session
from storage.database.student_manager import StudentManager, ProgressManager, StudentCreate, ProgressCreate, ProgressUpdate
from datetime import datetime


@tool
def save_progress_tool(
    runtime: ToolRuntime,
    student_name: str,
    grade: str,
    knowledge_point: str,
    subject: str,
    mastery_level: float = 0.5
) -> str:
    """
    保存或更新学生的学习进度
    
    Args:
        runtime: 工具运行时上下文
        student_name: 学生姓名
        grade: 年级(初中7年级、初中8年级、初中9年级、高一、高二、高三)
        knowledge_point: 知识点名称(如"二次函数"、"牛顿定律")
        subject: 科目(数学、语文、英语、物理、化学、生物、历史、地理、政治)
        mastery_level: 掌握度(0.0-1.0),默认0.5
    
    Returns:
        保存结果
    """
    try:
        db = get_session()
        try:
            # 获取或创建学生
            student_mgr = StudentManager()
            student = student_mgr.get_or_create_student(
                db, 
                name=student_name, 
                grade=grade, 
                subjects=subject
            )
            
            # 查找知识点
            from storage.database.shared.model import KnowledgePoint
            kp = db.query(KnowledgePoint).filter(
                KnowledgePoint.topic == knowledge_point,
                KnowledgePoint.subject == subject,
                KnowledgePoint.grade == grade
            ).first()
            
            if not kp:
                # 如果知识点不存在,创建一个
                kp = KnowledgePoint(
                    grade=grade,
                    subject=subject,
                    topic=knowledge_point,
                    difficulty="中等"
                )
                db.add(kp)
                db.commit()
                db.refresh(kp)
            
            # 保存进度
            progress_mgr = ProgressManager()
            progress = progress_mgr.save_progress(
                db,
                ProgressCreate(
                    student_id=student.id,
                    knowledge_point_id=kp.id,
                    mastery_level=mastery_level,
                    study_count=1
                )
            )
            
            return f"✅ 学习进度已保存!\n学生: {student_name}\n年级: {grade}\n科目: {subject}\n知识点: {knowledge_point}\n掌握度: {progress.mastery_level * 100:.1f}%\n学习次数: {progress.study_count}"
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 保存学习进度失败: {str(e)}"


@tool
def get_progress_tool(
    runtime: ToolRuntime,
    student_name: str,
    grade: str,
    subject: Optional[str] = None
) -> str:
    """
    获取学生的学习进度报告
    
    Args:
        runtime: 工具运行时上下文
        student_name: 学生姓名
        grade: 年级(初中7年级、初中8年级、初中9年级、高一、高二、高三)
        subject: 科目(可选),如果不指定则查询所有科目
    
    Returns:
        学习进度报告
    """
    try:
        db = get_session()
        try:
            from storage.database.shared.model import Student
            student_mgr = StudentManager()
            progress_mgr = ProgressManager()
            
            # 查找学生
            student = db.query(Student).filter(
                Student.name == student_name,
                Student.grade == grade
            ).first()
            
            if not student:
                return f"❌ 未找到学生: {student_name} ({grade})\n请先使用 save_progress_tool 记录学习数据。"
            
            # 获取进度摘要
            summary = progress_mgr.get_progress_summary(db, student.id)
            
            # 获取详细进度
            progress_list = progress_mgr.get_student_progress(db, student.id, subject)
            
            # 构建报告
            report = f"""📊 学习进度报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
学生: {student_name}
年级: {grade}
查询时间: {datetime.now().strftime("%Y-%m-%d %H:%M")}

📈 总体情况:
• 总知识点: {summary['总知识点']}
• 已学习: {summary['已学习']}
• 未学习: {summary['未学习']}
• 平均掌握度: {summary['平均掌握度']}

"""
            
            if progress_list:
                report += "📝 详细进度:\n"
                for idx, p in enumerate(progress_list[:20], 1):  # 最多显示20条
                    report += f"{idx}. [{p['科目']}] {p['知识点']} - 掌握度: {p['掌握度']} (学习{p['学习次数']}次)\n"
            else:
                report += "暂无学习记录。请开始学习后使用 save_progress_tool 记录进度。\n"
            
            return report
            
        finally:
            db.close()
            
    except Exception as e:
        return f"❌ 获取学习进度失败: {str(e)}"


if __name__ == "__main__":
    # 测试工具
    from langchain.tools import ToolRuntime
    from coze_coding_utils.runtime_ctx.context import new_context
    
    ctx = new_context(method="test")
    test_runtime = ToolRuntime(context=ctx)
    
    # 测试保存进度
    result1 = save_progress_tool.invoke({
        "student_name": "张三",
        "grade": "初中9年级",
        "knowledge_point": "二次函数",
        "subject": "数学",
        "mastery_level": 0.7,
        "runtime": test_runtime
    })
    print(result1)
    print("\n" + "="*60 + "\n")
    
    # 测试获取进度
    result2 = get_progress_tool.invoke({
        "student_name": "张三",
        "grade": "初中9年级",
        "subject": "数学",
        "runtime": test_runtime
    })
    print(result2)
