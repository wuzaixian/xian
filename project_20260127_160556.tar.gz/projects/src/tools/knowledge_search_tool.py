"""
知识库搜索工具 - 用于搜索考试大纲和知识点
"""
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk import KnowledgeClient, Config
from coze_coding_utils.runtime_ctx.context import Context


@tool
def knowledge_search_tool(query: str, runtime: ToolRuntime, grade: str = "初中9年级", subject: str = "数学") -> str:
    """
    根据年级和科目搜索考试大纲相关内容
    
    Args:
        query: 搜索关键词,如"二次函数"、"牛顿定律"等
        runtime: 工具运行时上下文
        grade: 年级,可选: 初中7年级、初中8年级、初中9年级、高一、高二、高三
        subject: 科目,如数学、语文、英语、物理、化学、生物、历史、地理、政治
    
    Returns:
        搜索结果,包含相关知识点内容
    """
    try:
        ctx = runtime.context
        config = Config()
        client = KnowledgeClient(config=config, ctx=ctx)
        
        # 构建搜索查询,包含年级和科目信息
        search_query = f"{grade} {subject} {query}"
        
        # 搜索知识库
        response = client.search(
            query=search_query,
            top_k=5,
            min_score=0.5
        )
        
        if response.code == 0 and response.chunks:
            results = []
            for i, chunk in enumerate(response.chunks, 1):
                results.append(f"【结果{i}】(相关度: {chunk.score:.2f})\n{chunk.content}\n")
            return "\n".join(results)
        else:
            return f"未找到关于 {grade}{subject} 中 '{query}' 的相关知识点。建议:\n1. 检查搜索关键词是否准确\n2. 尝试使用更通用的关键词\n3. 联系管理员更新知识库内容"
            
    except Exception as e:
        return f"知识库搜索失败: {str(e)}"


if __name__ == "__main__":
    # 测试工具
    from langchain.tools import ToolRuntime
    from coze_coding_utils.runtime_ctx.context import new_context
    
    ctx = new_context(method="test")
    test_runtime = ToolRuntime(context=ctx)
    
    result = knowledge_search_tool.invoke(
        {"query": "二次函数", "grade": "初中9年级", "subject": "数学", "runtime": test_runtime}
    )
    print(result)
