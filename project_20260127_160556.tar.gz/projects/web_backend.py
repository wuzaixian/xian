"""
中学生复习智能体 - Web后台管理系统
基于 Streamlit 构建
"""
import streamlit as st
import sys
import os

# 添加 src 目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from coze_coding_dev_sdk.database import get_session
from storage.database.admin_manager import (
    DashboardManager,
    AdminManager,
    AdminLogManager,
    ExamSyllabusManager,
    ExamSyllabusCreate
)
from storage.database.student_manager import StudentManager, ProgressManager
from storage.database.shared.model import Student, Progress, WrongAnswer

# 页面配置
st.set_page_config(
    page_title="中学生复习智能体 - 后台管理",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 自定义CSS
st.markdown("""
<style>
    .main-title {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .stMetric {
        background-color: #f0f2f6;
    }
</style>
""", unsafe_allow_html=True)


def init_session_state():
    """初始化会话状态"""
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'username' not in st.session_state:
        st.session_state.username = ''


def login_page():
    """登录页面"""
    st.title("🎓 后台管理系统")
    st.subheader("管理员登录")

    with st.form("login_form"):
        username = st.text_input("用户名", placeholder="请输入用户名")
        password = st.text_input("密码", type="password", placeholder="请输入密码")
        submit = st.form_submit_button("登录", use_container_width=True)

        if submit:
            db = get_session()
            try:
                admin_mgr = AdminManager()
                admin = admin_mgr.verify_admin(db, username, password)

                if admin:
                    st.session_state.logged_in = True
                    st.session_state.username = admin.username
                    st.success("登录成功！正在跳转...")
                    st.rerun()
                else:
                    st.error("用户名或密码错误！")
            finally:
                db.close()

    st.info("默认账号：admin / admin123456")


def dashboard_page():
    """仪表盘页面"""
    st.title("📊 系统概览")

    db = get_session()
    try:
        dashboard_mgr = DashboardManager()

        # 核心指标
        overview = dashboard_mgr.get_overview(db)

        col1, col2, col3, col4, col5 = st.columns(5)
        with col1:
            st.metric(label="学生总数", value=overview.get('学生总数', 0))
        with col2:
            st.metric(label="知识点总数", value=overview.get('知识点总数', 0))
        with col3:
            st.metric(label="题目总数", value=overview.get('题目总数', 0))
        with col4:
            st.metric(label="今日学习人数", value=overview.get('今日学习人数', 0))
        with col5:
            st.metric(label="错题总数", value=overview.get('错题总数', 0))

        st.divider()

        # 学生分布
        col1, col2 = st.columns(2)

        with col1:
            st.subheader("👥 学生分布（按年级）")
            student_stats = dashboard_mgr.get_student_stats(db)
            if student_stats:
                for stat in student_stats:
                    st.info(f"**{stat['年级']}**: {stat['学生人数']}人, 总学习时长 {stat['总学习时长']}")
            else:
                st.warning("暂无学生数据")

        with col2:
            st.subheader("🕐 最近活动")
            recent_activities = dashboard_mgr.get_recent_activities(db, limit=10)
            if recent_activities:
                for activity in recent_activities:
                    st.text(f"• [{activity['时间']}] {activity['学生']} ({activity['年级']}) - {activity['活动']}")
            else:
                st.warning("暂无最近活动")

    finally:
        db.close()


def students_page():
    """学生管理页面"""
    st.title("👥 学生管理")

    # 筛选器
    col1, col2 = st.columns(2)
    with col1:
        grade_filter = st.selectbox("筛选年级", ["全部", "初中7年级", "初中8年级", "初中9年级", "高一", "高二", "高三"])
    with col2:
        st.button("刷新数据", type="primary")

    db = get_session()
    try:
        query = db.query(Student)
        if grade_filter != "全部":
            query = query.filter(Student.grade == grade_filter)

        students = query.order_by(Student.created_at.desc()).all()

        if students:
            # 显示学生表格
            student_data = []
            for s in students:
                student_data.append({
                    "ID": s.id,
                    "姓名": s.name or "未设置",
                    "年级": s.grade,
                    "科目": s.subjects or "未设置",
                    "学习时长(小时)": f"{s.total_study_hours:.1f}",
                    "注册时间": s.created_at.strftime("%Y-%m-%d %H:%M")
                })

            st.dataframe(student_data, use_container_width=True)

            # 学生详情
            st.divider()
            st.subheader("学生详情")
            selected_student_id = st.selectbox(
                "选择学生查看详情",
                options=[s.id for s in students],
                format_func=lambda x: next(s.name for s in students if s.id == x)
            )

            if selected_student_id:
                student = next(s for s in students if s.id == selected_student_id)
                progress_mgr = ProgressManager()

                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("姓名", student.name or "未设置")
                with col2:
                    st.metric("年级", student.grade)
                with col3:
                    st.metric("总学习时长", f"{student.total_study_hours:.1f}小时")

                st.subheader("学习进度")
                progress_list = progress_mgr.get_student_progress(db, selected_student_id)

                if progress_list:
                    st.dataframe(progress_list, use_container_width=True)
                else:
                    st.info("暂无学习进度记录")

        else:
            st.warning("暂无学生数据")

    finally:
        db.close()


def syllabus_page():
    """考试大纲管理页面"""
    st.title("📚 考试大纲管理")

    # 标签页
    tab1, tab2 = st.tabs(["查看大纲", "添加大纲"])

    with tab1:
        st.subheader("考试大纲列表")

        # 筛选器
        col1, col2 = st.columns(2)
        with col1:
            grade_filter = st.selectbox("筛选年级", ["全部", "初中7年级", "初中8年级", "初中9年级", "高一", "高二", "高三"], key="syllabus_grade")
        with col2:
            subject_filter = st.selectbox("筛选科目", ["全部", "数学", "语文", "英语", "物理", "化学", "生物", "历史", "地理", "政治"], key="syllabus_subject")

        db = get_session()
        try:
            syllabus_mgr = ExamSyllabusManager()

            query_kwargs = {"is_active": True}
            if grade_filter != "全部":
                query_kwargs["grade"] = grade_filter
            if subject_filter != "全部":
                query_kwargs["subject"] = subject_filter

            syllabi = syllabus_mgr.get_syllabi(db, **query_kwargs)

            if syllabi:
                for s in syllabi:
                    with st.expander(f"📖 {s.grade} - {s.subject}: {s.title} (v{s.version})"):
                        st.markdown(s.content)
                        st.caption(f"创建时间: {s.created_at.strftime('%Y-%m-%d %H:%M')}")

                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button(f"编辑_{s.id}", key=f"edit_{s.id}"):
                                st.info("编辑功能开发中...")
                        with col2:
                            if st.button(f"删除_{s.id}", key=f"delete_{s.id}"):
                                if syllabus_mgr.delete_syllabus(db, s.id):
                                    st.success("删除成功！")
                                    st.rerun()
                                else:
                                    st.error("删除失败！")
            else:
                st.warning("暂无考试大纲数据")

        finally:
            db.close()

    with tab2:
        st.subheader("添加新考试大纲")

        with st.form("add_syllabus_form"):
            col1, col2 = st.columns(2)
            with col1:
                grade = st.selectbox("年级", ["初中7年级", "初中8年级", "初中9年级", "高一", "高二", "高三"])
            with col2:
                subject = st.selectbox("科目", ["数学", "语文", "英语", "物理", "化学", "生物", "历史", "地理", "政治"])

            title = st.text_input("大纲标题", placeholder="如：初中9年级数学考试大纲")
            content = st.text_area("大纲内容（Markdown格式）", height=300, placeholder="请输入考试大纲内容...")

            submit = st.form_submit_button("添加大纲", type="primary", use_container_width=True)

            if submit:
                if title and content:
                    db = get_session()
                    try:
                        syllabus_mgr = ExamSyllabusManager()
                        try:
                            syllabus_in = ExamSyllabusCreate(
                                grade=grade,
                                subject=subject,
                                title=title,
                                content=content,
                                version="1.0"
                            )
                            syllabus = syllabus_mgr.create_syllabus(db, syllabus_in, admin_id=1)

                            # 记录操作日志
                            log_mgr = AdminLogManager()
                            log_mgr.log_action(
                                db,
                                admin_id=1,
                                action="create_syllabus",
                                resource_type="exam_syllabus",
                                resource_id=syllabus.id,
                                details=f"创建考试大纲: {grade}{subject} - {title}"
                            )

                            st.success("✅ 考试大纲添加成功！")
                            st.rerun()
                        except ValueError as e:
                            st.error(f"⚠️ {str(e)}")
                    finally:
                        db.close()
                else:
                    st.warning("请填写完整的标题和内容！")


def logs_page():
    """操作日志页面"""
    st.title("📝 操作日志")

    # 筛选器
    col1, col2, col3 = st.columns(3)
    with col1:
        limit = st.selectbox("显示数量", [10, 20, 50, 100], index=1)

    db = get_session()
    try:
        from storage.database.shared.model import AdminLog, Admin

        logs = db.query(AdminLog, Admin).join(
            Admin, AdminLog.admin_id == Admin.id
        ).order_by(AdminLog.created_at.desc()).limit(limit).all()

        if logs:
            for log, admin in logs:
                with st.container():
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.markdown(f"**[{log.created_at.strftime('%Y-%m-%d %H:%M:%S')}]** - {admin.username}")
                    with col2:
                        st.caption(log.action)

                    if log.resource_type:
                        st.info(f"资源: {log.resource_type} (ID: {log.resource_id or 'N/A'})")

                    if log.details:
                        st.text(f"详情: {log.details}")

                    if log.ip_address:
                        st.caption(f"IP: {log.ip_address}")

                    st.divider()
        else:
            st.warning("暂无操作日志")

    finally:
        db.close()


def main():
    """主函数"""
    init_session_state()

    # 侧边栏
    with st.sidebar:
        st.title("🎓 复习智能体")
        st.divider()

        if st.session_state.logged_in:
            st.success(f"✅ 已登录: {st.session_state.username}")
            st.divider()

            page = st.radio(
                "导航",
                ["📊 仪表盘", "👥 学生管理", "📚 考试大纲", "📝 操作日志"],
                label_visibility="collapsed"
            )

            st.divider()

            if st.button("退出登录", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.username = ''
                st.rerun()
        else:
            page = "login"

        st.divider()
        st.caption("中学生复习智能体 v1.0")
        st.caption("后台管理系统")

    # 页面路由
    if page == "login":
        login_page()
    elif page == "📊 仪表盘":
        dashboard_page()
    elif page == "👥 学生管理":
        students_page()
    elif page == "📚 考试大纲":
        syllabus_page()
    elif page == "📝 操作日志":
        logs_page()


if __name__ == "__main__":
    main()
