"""
初始化后台管理员账号
"""
from coze_coding_dev_sdk.database import get_session
from storage.database.admin_manager import AdminManager, AdminCreate


def init_admin():
    """初始化默认管理员账号"""
    db = get_session()
    try:
        admin_mgr = AdminManager()
        
        # 创建默认管理员
        try:
            admin = admin_mgr.create_admin(
                db,
                AdminCreate(
                    username="admin",
                    password="admin123456",
                    email="admin@example.com",
                    role="super_admin"
                )
            )
            print("✅ 默认管理员账号创建成功!")
            print(f"   用户名: {admin.username}")
            print(f"   密码: admin123456")
            print(f"   角色: {admin.role}")
        except ValueError as e:
            if "已存在" in str(e):
                print("⚠️  默认管理员账号已存在")
            else:
                raise
    finally:
        db.close()


if __name__ == "__main__":
    init_admin()
