#!/bin/bash
# 启动Web后台服务脚本

echo "🚀 正在启动中学生复习智能体Web后台..."

cd /workspace/projects

# 检查streamlit是否安装
if ! python -c "import streamlit" 2>/dev/null; then
    echo "❌ Streamlit未安装，正在安装..."
    pip install streamlit
fi

# 启动服务
echo "✅ 启动服务..."
streamlit run web_backend.py --server.port 8501 --server.headless true

echo ""
echo "🎉 Web后台已启动！"
echo "📍 访问地址: http://localhost:8501"
echo "🔑 默认账号: admin / admin123456"
