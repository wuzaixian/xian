#!/bin/bash
# Web后台快速验证脚本

echo "🎉 中学生复习智能体 - Web后台管理系统"
echo "======================================"
echo ""

# 检查依赖
echo "📦 检查依赖..."
python -c "import streamlit" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ Streamlit已安装"
else
    echo "❌ Streamlit未安装，正在安装..."
    pip install streamlit
fi

python -c "import pandas" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ Pandas已安装"
else
    echo "❌ Pandas未安装，正在安装..."
    pip install pandas
fi

echo ""
echo "🔧 检查管理员账号..."
python -c "from coze_coding_dev_sdk.database import get_session; from storage.database.shared.model import Admin; db = get_session(); print('✅ 管理员账号存在' if db.query(Admin).first() else '❌ 需要初始化管理员账号'); db.close()"

if [ $? -ne 0 ]; then
    echo "初始化管理员账号..."
    PYTHONPATH=/workspace/projects/src:$PYTHONPATH python scripts/init_admin.py
fi

echo ""
echo "📊 检查数据库..."
python -c "from coze_coding_dev_sdk.database import get_session; from storage.database.shared.model import Student; db = get_session(); count = db.query(Student).count(); print(f'✅ 学生数据: {count}条'); db.close()"

python -c "from coze_coding_dev_sdk.database import get_session; from storage.database.shared.model import ExamSyllabus; db = get_session(); count = db.query(ExamSyllabus).count(); print(f'✅ 考试大纲: {count}条'); db.close()"

echo ""
echo "🚀 启动Web后台..."
echo ""
echo "════════════════════════════════════════════"
echo "📍 访问地址: http://localhost:8501"
echo "🌐 网络访问: http://169.254.101.215:8501"
echo "🔑 登录账号: admin / admin123456"
echo "════════════════════════════════════════════"
echo ""

streamlit run web_backend.py --server.port 8501
